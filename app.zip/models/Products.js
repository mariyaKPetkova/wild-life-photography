const { Schema, model } = require('mongoose')

const schema = new Schema({
    name: { type: String, required: [true, 'The title must be at least 6 symbols long'], min: 6 },
    keyword: { type: String, required: [true, 'The keyword must be at least 6 symbols long'], min: 6 },
    city: { type: String, required: [true, 'Location should be a maximum of 10 characters long'], max: 10 },
    date: { type: String, required: [true, 'Invalid Data'], match: [/[0-9]{2}.[0-9]{2}.[0-9]{4}/, 'The Date should be exactly 10 characters - 02.02.2021'] },
    imageUrl: { type: String, required: [true, 'Invalid URL'], match: [/^https?/, 'The Wildlife Image should start with http:// or https://.'] },
    description: { type: String, required: [true, 'The Description should be a minimum of 8 characters long.'], min: 8 },
    author: { type: Schema.Types.ObjectId, ref: 'User' }
    //booked: [{ type: Schema.Types.ObjectId, ref: 'User' }],
})

module.exports = model('Product', schema)