const Product = require('../models/Products.js')

async function createProduct(productData){
    const product = new Product(productData)
    await product.save()
    return Product
}

async function getAllProducts(){
    const products = await Product.find({}).lean()
    //search
    return products
}

async function getProductById(id){
    const product = await Product.findById(id).lean()
    
    return product
}

async function editProduct(id,productData){
    const product = await Product.findById(id)
    
    product.name = productData.name
    product.keyword = productData.keyword
    product.city = productData.city
    product.data = productData.data
    product.imageUrl = productData.imageUrl
    product.description = productData.description
    

    return product.save()
}
async function deleteProduct(product){
    return Product.findOneAndDelete(product)
    
    
}

module.exports = {
    createProduct,
    getAllProducts,
    getProductById,
    editProduct,
    deleteProduct
}